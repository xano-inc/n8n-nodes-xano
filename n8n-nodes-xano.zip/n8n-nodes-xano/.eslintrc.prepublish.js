/**
 * @type {import('@types/eslint').ESLint.ConfigData}
 */
module.exports = {
  extends: "./.eslintrc.js",
  // No need for overrides anymore
};
