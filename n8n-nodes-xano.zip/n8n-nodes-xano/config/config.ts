// export const baseUrl = {
// 	development: 'https://x8ki-letl-twmt.n7.xano.io'
// }

// export const getBaseUrl = (baseUrl: string) => ({
//   development: baseUrl
// });
